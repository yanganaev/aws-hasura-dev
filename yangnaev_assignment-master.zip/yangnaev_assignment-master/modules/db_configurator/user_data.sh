#!/bin/bash
echo "Starting user_data script for DB configurator" >> /var/log/cloud-init-output.log
sudo yum update -y
sudo yum install -y python3 python3-pip

# Install Python dependencies
pip3 install boto3 python-dotenv psycopg2-binary >> /var/log/cloud-init-output.log 2>&1

# Get parameters from SSM for configure_postgres.py
# Note: Directly getting parameters via AWS CLI inside user_data requires AWS CLI to be installed.
# Amazon Linux AMIs typically have it, but for other AMIs you might need to install it.
# aws ssm get-parameter requires AWS CLI, which is pre-installed on Amazon Linux AMIs.
export RDS_MASTER_USERNAME=$(aws ssm get-parameter --name "/dev/hasura/rds/master_username" --query "Parameter.Value" --output text --with-decryption)
export RDS_MASTER_PASSWORD=$(aws ssm get-parameter --name "/dev/hasura/rds/master_password" --with-decryption --query "Parameter.Value" --output text)
export HASURA_GRAPHQL_ADMIN_SECRET=$(aws ssm get-parameter --name "/dev/hasura/admin_secret" --with-decryption --query "Parameter.Value" --output text)
export DOMAIN_NAME=$(aws ssm get-parameter --name "/dev/hasura/domain_name" --query "Parameter.Value" --output text)

# Write a dummy .env file for load_dotenv() in the script (optional, but good practice if script expects it)
echo "RDS_MASTER_USERNAME=$RDS_MASTER_USERNAME" > /home/ec2-user/.env
echo "RDS_MASTER_PASSWORD=$RDS_MASTER_PASSWORD" >> /home/ec2-user/.env
echo "HASURA_GRAPHQL_ADMIN_SECRET=$HASURA_GRAPHQL_ADMIN_SECRET" >> /home/ec2-user/.env
echo "DOMAIN_NAME=$DOMAIN_NAME" >> /home/ec2-user/.env
chown ec2-user:ec2-user /home/ec2-user/.env
chmod 600 /home/ec2-user/.env

# Embed the configure_postgres.py script directly into user_data.
# This avoids needing S3 for script storage and fetching.
# IMPORTANT: The 'EOT' marker must be on its own line, no leading/trailing spaces.
cat << 'EOT' > /home/ec2-user/configure_postgres.py
import os
import boto3
import psycopg2
from dotenv import load_dotenv
import time

# Load environment variables from .env file
load_dotenv(override=True) # Use override=True to prefer .env values if set

# Initialize AWS SSM client
ssm_client = boto3.client('ssm')

def get_ssm_parameter(name, with_decryption=True):
    """Retrieves a parameter from SSM Parameter Store."""
    try:
        response = ssm_client.get_parameter(
            Name=name,
            WithDecryption=with_decryption
        )
        return response['Parameter']['Value']
    except Exception as e:
        print(f"Error retrieving parameter '{name}' from SSM: {e}")
        # In a production script, you might want to retry or raise an exception
        return None

def wait_for_rds_ready(host, user, password, dbname):
    """Waits until RDS becomes available."""
    print(f"Waiting for RDS database to be available at {host}...")
    max_retries = 60 # Increased retries
    retry_delay_seconds = 5 # Reduced delay for faster attempts
    for i in range(max_retries):
        try:
            conn = psycopg2.connect(
                host=host,
                user=user,
                password=password,
                dbname=dbname,
                connect_timeout=5 # Connection timeout for psycopg2
            )
            conn.close()
            print("RDS database is available.")
            return True
        except psycopg2.OperationalError as e:
            print(f"Database is not ready yet: {e}. Retrying in {retry_delay_seconds} seconds... (Attempt {i+1}/{max_retries})")
            time.sleep(retry_delay_seconds)
    print("Failed to connect to RDS database after multiple attempts.")
    return False

def configure_postgres():
    """Configures PostgreSQL: creates Hasura user and schemas."""
    # Fetch parameters directly in Python for robustness, as user_data sets env vars
    # but the script's get_ssm_parameter also uses boto3
    db_host = get_ssm_parameter('/dev/hasura/rds/db_endpoint', with_decryption=False) # Endpoint will be set by Terraform
    db_port = "5432" # Standard PostgreSQL port
    db_user = get_ssm_parameter('/dev/hasura/rds/master_username')
    db_password = get_ssm_parameter('/dev/hasura/rds/master_password')
    db_name = "hasuradb" # Database name created by Terraform

    if not all([db_host, db_user, db_password, db_name]):
        print("Failed to retrieve all necessary database parameters from SSM. Ensure Terraform has successfully completed RDS deployment and SSM parameters are populated.")
        return

    # Wait until RDS becomes available
    if not wait_for_rds_ready(db_host, db_user, db_password, db_name):
        print("Could not connect to the database. Check RDS logs and network configuration.")
        return

    conn = None
    try:
        # Connect to the PostgreSQL database
        conn = psycopg2.connect(
            host=db_host,
            port=db_port,
            user=db_user,
            password=db_password,
            dbname=db_name
        )
        conn.autocommit = True # Auto-commit changes
        cur = conn.cursor()

        # 1. Create Hasura user if it doesn't exist
        hasura_db_user = "hasura_app_user"
        print(f"Checking for existence of user '{hasura_db_user}'...")
        cur.execute(f"SELECT 1 FROM pg_roles WHERE rolname='{hasura_db_user}';")
        if not cur.fetchone():
            print(f"Creating user '{hasura_db_user}'...")
            cur.execute(f"CREATE USER {hasura_db_user} WITH PASSWORD '{get_ssm_parameter('/dev/hasura/admin_secret')}';")
            # For Hasura, READ access is usually sufficient. But since this is a dev environment, we'll grant broader permissions.
            cur.execute(f"GRANT CONNECT ON DATABASE {db_name} TO {hasura_db_user};")
            # Not granting ALL PRIVILEGES on the database itself yet, will grant on schemas
            print(f"User '{hasura_db_user}' created.")
        else:
            print(f"User '{hasura_db_user}' already exists.")

        # 2. Create 5 separate schemas
        schemas = [f"schema_dev_{i}" for i in range(1, 6)]
        for schema in schemas:
            print(f"Checking for existence of schema '{schema}'...")
            cur.execute(f"SELECT schema_name FROM information_schema.schemata WHERE schema_name = '{schema}';")
            if not cur.fetchone():
                print(f"Creating schema '{schema}'...")
                cur.execute(f"CREATE SCHEMA {schema};")
                print(f"Schema '{schema}' created.")
            else:
                print(f"Schema '{schema}' already exists.")

            # Grant permissions to the Hasura user on the schemas
            print(f"Granting permissions on schema '{schema}' to user '{hasura_db_user}'...")
            cur.execute(f"GRANT USAGE ON SCHEMA {schema} TO {hasura_db_user};")
            cur.execute(f"GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA {schema} TO {hasura_db_user};")
            cur.execute(f"GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA {schema} TO {hasura_db_user};")
            cur.execute(f"ALTER DEFAULT PRIVILEGES IN SCHEMA {schema} GRANT ALL PRIVILEGES ON TABLES TO {hasura_db_user};")
            print(f"Permissions on schema '{schema}' granted.")

        # 3. Update HASURA_GRAPHQL_DATABASE_URL in SSM Parameter Store
        # This is the connection string that Hasura will use.
        hasura_db_url = f"postgresql://{hasura_db_user}:{get_ssm_parameter('/dev/hasura/admin_secret')}@{db_host}:{db_port}/{db_name}"
        print(f"Updating parameter '/dev/hasura/db_url' in SSM Parameter Store...")
        ssm_client.put_parameter(
            Name='/dev/hasura/db_url',
            Value=hasura_db_url,
            Type='String', # This is not a secret, but a connection URL
            Overwrite=True
        )
        print(f"Parameter '/dev/hasura/db_url' successfully updated: {hasura_db_url}")

        print("PostgreSQL configuration completed.")

    except Exception as e:
        print(f"An error occurred during PostgreSQL configuration: {e}")
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    configure_postgres()
EOT

# Execute the Python script as ec2-user (or root if needed)
chown ec2-user:ec2-user /home/ec2-user/configure_postgres.py
chmod +x /home/ec2-user/configure_postgres.py
sudo -u ec2-user python3 /home/ec2-user/configure_postgres.py >> /var/log/cloud-init-output.log 2>&1
echo "Finished user_data script." >> /var/log/cloud-init-output.log